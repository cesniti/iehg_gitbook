If you want to test IENC data then you must replace the S101_FC_0.8.xml in your install directory with the version found in the IENC_Feature_Catalog folder in this directory.
